var  clock = document.getElementById('clock');

function ShowClock(){
    var timendate = new Date();
    var formattedtimendate = formatClock(timendate);
    clock.textContent = formattedtimendate;
}
function formatClock(timendate){
    var f = timendate.toString();
    f = f.slice(0,f.search('G')-1);// to find G here "Sat Dec 26 2020 20:23:07 GMT+0300"
    return f;
}

function wallpaper(){
    var wall = "url('/img/i.jpeg')";
    const time = new Date();
    var h = time.getHours();
    var timevalue = h*60 + time.getMinutes();
    let vall = [0, 90, 180, 270, 360, 450, 540, 630, 720, 810, 900, 990, 1080, 1170, 1260, 1350, 1440];
    for (let i = 0; i < 16; i++) {
        if (timevalue <= vall[i]){ 
            wall = "url('/img/" + i + ".jpeg')";
            document.body.style.backgroundImage = wall;
            break;
        }
    }
    document.body.style.backgroundSize = 'cover';
    document.body.style.backgroundRepeat = 'no-repeat'
}


/*
0:00 =    1
1:30 =    2
3:00 =    3 
4:30 =    4
6:00 =    5  
7:30 =    6
9:00 =    7
10:30 =   8
12:00 =   9
13:30 =   10
15:00 =   11
16:30 =   12 
18:00 =   13
19:30 =   14
21:00 =   15
22:30 =   16
*/
//wallpaper();
setInterval(ShowClock, 1000);
wallpaper();