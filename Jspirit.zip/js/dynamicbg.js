var a = "url('/img/i.jpeg')";
a[13] = toString(5);
console.log(a);